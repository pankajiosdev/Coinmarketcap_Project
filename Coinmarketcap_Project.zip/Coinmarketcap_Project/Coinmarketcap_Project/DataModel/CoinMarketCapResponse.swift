//
//  CoinMarketCapResponse.swift
//  Coinmarketcap_Project
//
//  Created by Admin on 15/11/23.
//

import Foundation

struct CoinMarketCapResponse: Codable {
    let status : Status?
    let data : [Data]?
    
    enum CodingKeys: String, CodingKey {
        
        case status = "status"
        case data = "data"
    }
}
struct Status : Codable {
    let timestamp : String?
    let error_code : Double?
    let error_message : String?
    let elapsed : Double?
    let credit_count : Double?
    let notice : String?
    let total_count : Double?
    
    enum CodingKeys: String, CodingKey {
        
        case timestamp = "timestamp"
        case error_code = "error_code"
        case error_message = "error_message"
        case elapsed = "elapsed"
        case credit_count = "credit_count"
        case notice = "notice"
        case total_count = "total_count"
    }
}

struct Quote : Codable {
    let uSD : USD?
    
    enum CodingKeys: String, CodingKey {
        
        case uSD = "USD"
    }
}

struct USD : Codable {
    let price : Double?
    let volume_24h : Double?
    let volume_change_24h : Double?
    let percent_change_1h : Double?
    let percent_change_24h : Double?
    let percent_change_7d : Double?
    let percent_change_30d : Double?
    let percent_change_60d : Double?
    let percent_change_90d : Double?
    let market_cap : Double?
    let market_cap_dominance : Double?
    let fully_diluted_market_cap : Double?
    let tvl : String?
    let last_updated : String?
    
    enum CodingKeys: String, CodingKey {
        
        case price = "price"
        case volume_24h = "volume_24h"
        case volume_change_24h = "volume_change_24h"
        case percent_change_1h = "percent_change_1h"
        case percent_change_24h = "percent_change_24h"
        case percent_change_7d = "percent_change_7d"
        case percent_change_30d = "percent_change_30d"
        case percent_change_60d = "percent_change_60d"
        case percent_change_90d = "percent_change_90d"
        case market_cap = "market_cap"
        case market_cap_dominance = "market_cap_dominance"
        case fully_diluted_market_cap = "fully_diluted_market_cap"
        case tvl = "tvl"
        case last_updated = "last_updated"
    }
    
}
struct Data : Codable {
    let id : Int?
    let name : String?
    let symbol : String?
    let slug : String?
    let num_market_pairs : Double?
    let date_added : String?
    let tags : [String]?
    let max_supply : Double?
    let circulating_supply : Double?
    let total_supply : Double?
    let infinite_supply : Bool?
    let platform : Platform?
    let cmc_rank : Double?
    let self_reported_circulating_supply : Double?
    let self_reported_market_cap : Double?
    let tvl_ratio : String?
    let last_updated : String?
    let quote : Quote?
    
    enum CodingKeys: String, CodingKey {
        
        case id = "id"
        case name = "name"
        case symbol = "symbol"
        case slug = "slug"
        case num_market_pairs = "num_market_pairs"
        case date_added = "date_added"
        case tags = "tags"
        case max_supply = "max_supply"
        case circulating_supply = "circulating_supply"
        case total_supply = "total_supply"
        case infinite_supply = "infinite_supply"
        case platform = "platform"
        case cmc_rank = "cmc_rank"
        case self_reported_circulating_supply = "self_reported_circulating_supply"
        case self_reported_market_cap = "self_reported_market_cap"
        case tvl_ratio = "tvl_ratio"
        case last_updated = "last_updated"
        case quote = "quote"
    }
}

struct Platform : Codable {
    let id : Double?
    let name : String?
    let symbol : String?
    let slug : String?
    let token_address : String?
}

struct YourSecondAPIResponseModel: Decodable {
    let status: Status?
    let data: [String: SecondAPIItem]?

    struct SecondAPIItem: Decodable {
        let id: Int?
        let name: String?
        let symbol: String?
        let category: String?
        let description: String?
        let slug: String?
        let logo: String?
        let subreddit: String?
        let notice: String?
        let tags: [String]?
        let tagNames: [String]?
        let tagGroups: [String]?
        let urls: URLs?
        let platform: Platform?
        let dateAdded: String?
        let twitterUsername: String?
        let isHidden: Int?
        let date_launched: String?
        let contractAddress: [ContractAddress]?
        let selfReportedCirculatingSupply: Double?
        let selfReportedTags: [String]?
        let selfReportedMarketCap: Double?
        let infiniteSupply: Bool?

        struct URLs: Decodable {
            let website: [String]?
            let twitter: [String]?
            let message_board: [String]?
            let chat: [String]?
            let facebook: [String]?
            let explorer: [String]?
            let reddit: [String]?
            let technical_doc: [String]?
            let source_code: [String]?
            let announcement: [String]?
        }

        struct Platform: Decodable {
            let id: String?
            let name: String?
            let slug: String?
            let symbol: String?
            let token_address: String?
        }

        struct ContractAddress: Decodable {
            let contractAddress: String?
            let platform: Platform?
        }

        enum CodingKeys: String, CodingKey {
            case id
            case name
            case symbol
            case category
            case description
            case slug
            case logo
            case subreddit
            case notice
            case tags
            case tagNames = "tag-names"
            case tagGroups = "tag-groups"
            case urls
            case platform
            case dateAdded = "date_added"
            case twitterUsername = "twitter_username"
            case isHidden = "is_hidden"
            case date_launched = "date_launched"
            case contractAddress = "contract_address"
            case selfReportedCirculatingSupply = "self_reported_circulating_supply"
            case selfReportedTags = "self_reported_tags"
            case selfReportedMarketCap = "self_reported_market_cap"
            case infiniteSupply = "infinite_supply"
        }
    }
}

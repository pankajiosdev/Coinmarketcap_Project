//
//  MyTableViewCell.swift
//  Coinmarketcap_Project
//
//  Created by Admin on 16/11/23.
//

import UIKit

class MyTableViewCell: UITableViewCell {

    
    @IBOutlet weak var logoImg: UIImageView!
    @IBOutlet weak var sortNamee: UILabel!
    @IBOutlet weak var priceLbl: UILabel!
    @IBOutlet weak var fullNameLBl: UILabel!
    @IBOutlet weak var percentagerDropageLbl: UILabel!
    @IBOutlet weak var graphImg: UIImageView!
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        SeparatorStyle.none
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}

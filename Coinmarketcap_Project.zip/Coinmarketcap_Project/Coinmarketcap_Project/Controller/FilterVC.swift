//
//  FilterVC.swift
//  Coinmarketcap_Project
//
//  Created by Admin on 16/11/23.
//

import UIKit

class FilterVC: UIViewController {

    
    
    @IBOutlet weak var viewMain: UIView!
    
    // Declare a variable to store the callback
    var callback: ((String) -> Void)?

    override func viewDidLoad() {
        super.viewDidLoad()
        viewMain.layer.cornerRadius = 15
    }

    @IBAction func backBtnAction(_ sender: Any) {
        dismiss(animated: true)
    }

    @IBAction func lowToHighBtnAction(_ sender: Any) {
        sendDataAndDismiss("lowToHigh")
    }

    @IBAction func highToLowBtnAction(_ sender: Any) {
        sendDataAndDismiss("highToLow")
    }

    @IBAction func volume24BtnAction(_ sender: Any) {
        sendDataAndDismiss("volume")
    }

    // Function to send data and dismiss the view controller
    private func sendDataAndDismiss(_ data: String) {
        if let callback = callback {
            // Call the callback function and pass the data
            callback(data)
        }
        // Dismiss the view controller after sending the data
        dismiss(animated: true, completion: nil)
    }
}

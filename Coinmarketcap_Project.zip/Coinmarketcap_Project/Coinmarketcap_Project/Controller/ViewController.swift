//
//  ViewController.swift
//  Coinmarketcap_Project
//
//  Created by Admin on 15/11/23.
//
import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var tableView: UITableView!
    @IBOutlet weak var viewSearch: UIView!
    @IBOutlet weak var searchTft: UITextField!
    @IBOutlet weak var filterBtn: UIButton!
    @IBOutlet weak var viewCryptocurrency: UIView!
    
    var cryptoListings: [Data] = []
    var logoId: [Int:String] = [:]
    var isAscendingOrder = true
    
    override func viewDidLoad() {
        super.viewDidLoad()
        fetchCoinMarketCapListings()
        uiMakeup()
        
    }
    // MARK: filter functionality--
    func sortHighToLow() {
        cryptoListings.sort { $0.quote?.uSD?.price ?? 0.0 > $1.quote?.uSD?.price ?? 0.0 }
    }
    func sortLowToHigh() {
        cryptoListings.sort { $0.quote?.uSD?.price ?? 0.0 < $1.quote?.uSD?.price ?? 0.0 }
    }
    func sortVolue24(){
        cryptoListings.sort { $0.quote?.uSD?.volume_24h ?? 0.0 < $1.quote?.uSD?.volume_24h ?? 0.0 }
    }
    
    // MARK: UI Desing--
    func uiMakeup(){
        viewCryptocurrency.layer.cornerRadius = 10
        viewSearch.layer.cornerRadius = viewSearch.frame.size.height/2
        filterBtn.layer.cornerRadius = filterBtn.frame.height/2
        filterBtn.layer.borderWidth = 1
        filterBtn.layer.borderColor = UIColor(red: 0.042, green: 0.042, blue: 0.042, alpha: 0.3).cgColor
        tableView.register(UINib(nibName: "MyTableViewCell", bundle: nil), forCellReuseIdentifier: "MyTableViewCell")
        tableView.dataSource = self
        tableView.delegate = self
        tableView.separatorStyle = .none
    }
    
    // MARK: API call for logo--
    func fetchSecondAPI(ids: [Int]) {
        let idString = ids.map { String($0) }.joined(separator: ",")
        let apiKey = "f460ab56-d605-49e0-8788-cb490e080c9e"
        let secondAPIURLString = "https://pro-api.coinmarketcap.com/v2/cryptocurrency/info?CMC_PRO_API_KEY=\(apiKey)&id=\(idString)"
        
        guard let secondAPIURL = URL(string: secondAPIURLString) else { return }
        
        let task = URLSession.shared.dataTask(with: secondAPIURL) { (data, response, error) in
            if let data = data, error == nil {
                do {
                    let decoder = JSONDecoder()
                    let result = try decoder.decode(YourSecondAPIResponseModel.self, from: data)
                    
                    
                    // Process the result from the second API call
                    if let secondAPIItems = result.data {
                        // Now 'SecondAPIItem' is available in the scope
                        for (_, item) in secondAPIItems {
                            // Append to the dictionary
                            self.logoId[item.id!] = item.logo!                                          }
                    }
                    // Reload the table view on the main thread
                    DispatchQueue.main.async {
                        self.tableView.reloadData()
                    }
                    
                } catch {
                    print("Error decoding second API JSON: \(error)")
                }
            } else {
                print("Error fetching second API data: \(error?.localizedDescription ?? "Unknown error")")
            }
        }
        
        task.resume()
    }
    
    // MARK: API Call for Listing--
    func fetchCoinMarketCapListings() {
        let apiKey = "f460ab56-d605-49e0-8788-cb490e080c9e"
        let urlString = "https://pro-api.coinmarketcap.com/v1/cryptocurrency/listings/latest?CMC_PRO_API_KEY=\(apiKey)&limit=20"
        
        guard let url = URL(string: urlString) else { return }
        
        let task = URLSession.shared.dataTask(with: url) { (data, response, error) in
            if let data = data, error == nil {
                do {
                    let decoder = JSONDecoder()
                    let result = try decoder.decode(CoinMarketCapResponse.self, from: data)
                    self.cryptoListings = result.data ?? []
                    
                    let ids = self.cryptoListings.compactMap { $0.id }
                    self.fetchSecondAPI(ids: ids)
                    
                    DispatchQueue.main.async {
                        self.tableView.reloadData()
                    }
                } catch {
                    print("Error decoding JSON: \(error)")
                }
            } else {
                print("Error fetching data: \(error?.localizedDescription ?? "Unknown error")")
            }
        }
        
        task.resume()
    }
    
    @IBAction func filterBtnAction(_ sender: Any) {
        let controller = FilterVC()
        controller.callback = { selectedFilter in
            // Handle the selected filter here
            if selectedFilter == "highToLow" {
                self.sortHighToLow()
                self.tableView.reloadData()
            }else if selectedFilter == "lowToHigh" {
                self.sortLowToHigh()
                self.tableView.reloadData()
            }else{
                self.sortVolue24()
                self.tableView.reloadData()
            }
        }
        controller.providesPresentationContextTransitionStyle = true
        controller.definesPresentationContext = true
        controller.modalPresentationStyle = UIModalPresentationStyle.overCurrentContext
        controller.modalTransitionStyle = .crossDissolve
        self.present(controller, animated: true, completion: nil)
        
    }
    
    
    
}
extension ViewController: UITableViewDelegate, UITableViewDataSource{
    // MARK: - UITableViewDataSource
        func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return cryptoListings.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "MyTableViewCell", for: indexPath) as! MyTableViewCell
        
        if let logoURLString = logoId[cryptoListings[indexPath.row].id!],
           let logoURL = URL(string: logoURLString) {
            let task = URLSession.shared.dataTask(with: logoURL) { (data, response, error) in
                if let error = error {
                    print("Error downloading image: \(error)")
                    // Handle the error, set a placeholder image, or perform other error handling
                    DispatchQueue.main.async {
                        cell.logoImg.image = UIImage(named: "defaultLogo")
                    }
                    return
                }
                
                guard let data = data else {
                    print("No data received for the image.")
                    // Handle the case where no data is received
                    DispatchQueue.main.async {
                        cell.logoImg.image = UIImage(named: "defaultLogo")
                    }
                    return
                }
                
                if let image = UIImage(data: data) {
                    // Update UI on the main thread
                    DispatchQueue.main.async {
                        cell.logoImg.image = image
                    }
                } else {
                    print("Failed to create UIImage from data.")
                    // Handle the case where UIImage creation fails
                    DispatchQueue.main.async {
                        cell.logoImg.image = UIImage(named: "defaultLogo")
                    }
                }
            }
            
            task.resume()
        } else {
            print("Invalid or missing URL for the image.")
            // Handle the case where the URL is invalid or not found
            cell.logoImg.image = UIImage(named: "defaultLogo")
        }
        
        cell.sortNamee.text = cryptoListings[indexPath.row].symbol ?? ""
        cell.fullNameLBl.text = cryptoListings[indexPath.row].name ?? ""
        // Format price with two decimal places
        
        let price = Int(cryptoListings[indexPath.row].quote?.uSD?.price ?? 0.0)
        
        if price == 0 {
            let realPrice = cryptoListings[indexPath.row].quote?.uSD?.price ?? 0.0
            let formattedPricee = String(format: "%.2f", abs(realPrice))
            cell.priceLbl.text = "$\(formattedPricee) USD"
        } else {
            cell.priceLbl.text = "$\(price) USD"
        }
        
        // Format percentage with two decimal places
        let percentageChange = cryptoListings[indexPath.row].quote?.uSD?.volume_change_24h ?? 0.0
        let formattedPercentage = String(format: "%.1f", abs(percentageChange))
        
        if percentageChange > 0 {
            cell.graphImg.image = UIImage(named: "greenGraph")
            cell.percentagerDropageLbl.text = "+\(formattedPercentage)%"
            cell.percentagerDropageLbl.textColor = UIColor(red: 0, green: 0.809, blue: 0.032, alpha: 1)
        } else {
            cell.graphImg.image = UIImage(named: "redGraph")
            cell.percentagerDropageLbl.text = "-\(formattedPercentage)%"
            cell.percentagerDropageLbl.textColor = UIColor(red: 1, green: 0.24, blue: 0, alpha: 1)
        }
        
        return cell
    }
    
    
}
